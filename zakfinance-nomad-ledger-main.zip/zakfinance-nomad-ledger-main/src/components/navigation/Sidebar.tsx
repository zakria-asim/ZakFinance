
import { cn } from "@/lib/utils";
import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { 
  ChevronLeft, 
  ChevronRight, 
  LayoutDashboard, 
  FileText, 
  BarChart4, 
  Settings, 
  LogOut 
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

interface SidebarProps {
  isOpen: boolean;
  setIsOpen: (value: boolean) => void;
}

interface SidebarItemProps {
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  isActive?: boolean;
}

const SidebarItem: React.FC<SidebarItemProps> = ({
  href,
  icon: Icon,
  title,
  isActive,
}) => {
  return (
    <Link
      to={href}
      className={cn(
        "flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:bg-card hover:text-foreground",
        isActive ? "bg-card text-foreground" : ""
      )}
    >
      <Icon className={cn("h-5 w-5", isActive ? "text-primary" : "")} />
      <span>{title}</span>
    </Link>
  );
};

const Sidebar = ({ isOpen, setIsOpen }: SidebarProps) => {
  const location = useLocation();
  const { logout } = useAuth();

  const navItems = [
    {
      title: "Dashboard",
      href: "/dashboard",
      icon: LayoutDashboard,
    },
    {
      title: "Transactions",
      href: "/transactions",
      icon: FileText,
    },
    {
      title: "Reports",
      href: "/reports",
      icon: BarChart4,
    },
    {
      title: "Settings",
      href: "/settings",
      icon: Settings,
    },
  ];

  return (
    <aside
      className={cn(
        "group fixed inset-y-0 left-0 z-40 flex flex-col border-r border-border/50 bg-background/95 backdrop-blur transition-all duration-300 ease-in-out md:relative",
        isOpen ? "w-64" : "w-16"
      )}
    >
      <div className="flex h-16 items-center justify-between border-b border-border/50 px-4">
        <div 
          className={cn(
            "flex items-center gap-2 transition-all", 
            !isOpen && "opacity-0"
          )}
        >
          <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-lg font-bold text-primary-foreground">
            Z
          </div>
          <span className="text-lg font-semibold whitespace-nowrap">ZakFinance</span>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <ChevronLeft className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
        </Button>
      </div>

      <div className="flex-1 overflow-auto py-4">
        <nav className="grid gap-1 px-2">
          {navItems.map((item) => (
            <div key={item.href} className={cn(!isOpen && "px-2 py-1 mx-auto")}>
              {isOpen ? (
                <SidebarItem
                  href={item.href}
                  icon={item.icon}
                  title={item.title}
                  isActive={location.pathname === item.href}
                />
              ) : (
                <Link
                  to={item.href}
                  className={cn(
                    "flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-card hover:text-foreground",
                    location.pathname === item.href ? "bg-card text-primary" : ""
                  )}
                  title={item.title}
                >
                  <item.icon className="h-5 w-5" />
                </Link>
              )}
            </div>
          ))}
        </nav>
      </div>

      <div className="mt-auto border-t border-border/50 p-4">
        {isOpen ? (
          <Button 
            variant="ghost" 
            className="w-full justify-start gap-2 text-muted-foreground" 
            onClick={() => logout()}
          >
            <LogOut className="h-5 w-5" />
            <span>Logout</span>
          </Button>
        ) : (
          <Button 
            variant="ghost" 
            size="icon" 
            className="mx-auto" 
            onClick={() => logout()}
          >
            <LogOut className="h-5 w-5" />
          </Button>
        )}
      </div>
    </aside>
  );
};

export default Sidebar;
