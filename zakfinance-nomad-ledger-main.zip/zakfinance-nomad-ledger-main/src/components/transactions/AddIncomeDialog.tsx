
import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { useToast } from "@/components/ui/use-toast";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";

interface AddIncomeDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onTransactionAdded: () => void;
}

interface BankAccount {
  id: string;
  name: string;
  currency: string;
  balance: number;
}

interface Category {
  id: string;
  name: string;
}

const AddIncomeDialog = ({ open, onOpenChange, onTransactionAdded }: AddIncomeDialogProps) => {
  const { toast } = useToast();
  const [date, setDate] = useState<Date>(new Date());
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedBankAccount, setSelectedBankAccount] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  // Fetch bank accounts and categories on dialog open
  useEffect(() => {
    if (open) {
      fetchBankAccounts();
      fetchCategories();
    }
  }, [open]);

  const fetchBankAccounts = async () => {
    try {
      const { data, error } = await supabase
        .from('bank_accounts')
        .select('*');
      
      if (error) throw error;
      setBankAccounts(data || []);
      
      if (data && data.length > 0) {
        setSelectedBankAccount(data[0].id);
      }
    } catch (error) {
      console.error('Error fetching bank accounts:', error);
    }
  };

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .eq('type', 'income');
      
      if (error) throw error;
      setCategories(data || []);
      
      if (data && data.length > 0) {
        setSelectedCategory(data[0].id);
      }
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      if (!amount || !selectedBankAccount || !selectedCategory) {
        toast({
          title: "Missing information",
          description: "Please fill in all required fields",
          variant: "destructive"
        });
        return;
      }
      
      // Get the selected bank account to determine currency
      const bankAccount = bankAccounts.find(account => account.id === selectedBankAccount);
      if (!bankAccount) {
        toast({
          title: "Invalid bank account",
          description: "Please select a valid bank account",
          variant: "destructive"
        });
        return;
      }
      
      const parsedAmount = parseFloat(amount);
      
      if (isNaN(parsedAmount) || parsedAmount <= 0) {
        toast({
          title: "Invalid amount",
          description: "Please enter a valid positive number",
          variant: "destructive"
        });
        return;
      }
      
      // Get current exchange rate (for simplicity using a fixed rate here)
      let exchangeRate = 1;
      let convertedAmount = parsedAmount;
      let convertedCurrency = bankAccount.currency;
      
      if (bankAccount.currency === 'USD') {
        // Get USD to PKR rate from the database
        const { data: rateData } = await supabase
          .from('exchange_rates')
          .select('rate')
          .eq('from_currency', 'USD')
          .eq('to_currency', 'PKR')
          .order('created_at', { ascending: false })
          .limit(1);
        
        if (rateData && rateData.length > 0) {
          exchangeRate = rateData[0].rate;
        } else {
          exchangeRate = 279.5; // Fallback rate
        }
        
        convertedAmount = parsedAmount * exchangeRate;
        convertedCurrency = 'PKR';
      } else if (bankAccount.currency === 'PKR') {
        exchangeRate = 1;
      }
      
      // Get the user's ID
      const { data: sessionData } = await supabase.auth.getSession();
      if (!sessionData.session) {
        toast({
          title: "Authentication Error",
          description: "You must be signed in to add a transaction",
          variant: "destructive"
        });
        return;
      }
      const userId = sessionData.session.user.id;
      
      // Insert the transaction - Fix: Don't wrap the object in an array
      const { data, error } = await supabase
        .from('transactions')
        .insert({
          user_id: userId,
          bank_account_id: selectedBankAccount,
          category_id: selectedCategory,
          type: 'income',
          original_amount: parsedAmount,
          original_currency: bankAccount.currency,
          converted_amount: convertedAmount,
          converted_currency: convertedCurrency,
          conversion_rate: exchangeRate,
          description: description,
          transaction_date: date.toISOString().split('T')[0]
        });
        
      if (error) throw error;
      
      toast({
        title: "Income added",
        description: "Your income has been recorded successfully",
      });
      
      // Reset form
      setAmount("");
      setDescription("");
      setDate(new Date());
      
      // Close dialog and notify parent
      onOpenChange(false);
      onTransactionAdded();
      
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to add income",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Add Income</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="bank-account">Bank Account</Label>
              <Select
                value={selectedBankAccount}
                onValueChange={setSelectedBankAccount}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select bank account" />
                </SelectTrigger>
                <SelectContent>
                  {bankAccounts.map((account) => (
                    <SelectItem key={account.id} value={account.id}>
                      {account.name} ({account.currency})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="category">Category</Label>
              <Select
                value={selectedCategory}
                onValueChange={setSelectedCategory}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="amount">Amount</Label>
              <Input
                id="amount"
                type="number"
                step="0.01"
                placeholder="Enter amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                required
              />
            </div>

            <div className="grid gap-2">
              <Label>Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !date && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {date ? format(date, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={(newDate) => newDate && setDate(newDate)}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="description">Description (Optional)</Label>
              <Textarea
                id="description"
                placeholder="Add more details about this income"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" type="button" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Adding..." : "Add Income"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddIncomeDialog;
