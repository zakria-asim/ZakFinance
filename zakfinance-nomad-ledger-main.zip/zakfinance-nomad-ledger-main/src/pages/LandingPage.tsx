
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const LandingPage = () => {
  return (
    <div className="flex min-h-screen flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border/50 bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
              Z
            </div>
            <span className="text-lg font-semibold">ZakFinance</span>
          </div>
          <nav className="flex items-center gap-4">
            <Link to="/signin">
              <Button variant="ghost">Sign In</Button>
            </Link>
            <Link to="/signup">
              <Button>Get Started</Button>
            </Link>
          </nav>
        </div>
      </header>

      {/* Hero section */}
      <section className="relative">
        <div className="container flex flex-col items-center justify-center py-20 text-center md:py-32">
          <div className="absolute inset-0 -z-10 overflow-hidden">
            <div className="absolute left-1/3 top-1/4 h-64 w-64 rounded-full bg-primary/20 blur-3xl"></div>
            <div className="absolute right-1/4 top-1/2 h-64 w-64 rounded-full bg-secondary/20 blur-3xl"></div>
          </div>
          
          <h1 className="mb-6 text-4xl font-bold tracking-tight md:text-6xl">
            Smart Finance for <br />
            <span className="text-primary">Global Freelancers</span>
          </h1>
          
          <p className="mb-8 max-w-[600px] text-muted-foreground md:text-lg">
            Track your income and expenses across multiple currencies and bank accounts in one beautiful dashboard
          </p>
          
          <div className="flex flex-col gap-4 sm:flex-row">
            <Link to="/signup">
              <Button size="lg" className="min-w-[160px]">
                Get Started
              </Button>
            </Link>
            <Link to="/signin">
              <Button size="lg" variant="outline" className="min-w-[160px]">
                Sign In
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="border-t border-border bg-card py-16">
        <div className="container">
          <h2 className="mb-12 text-center text-3xl font-bold">Why ZakFinance?</h2>
          
          <div className="grid gap-8 md:grid-cols-3">
            <div className="glass rounded-lg p-6">
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/20 text-primary">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="h-6 w-6">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v17.25m0 0c-1.472 0-2.882.265-4.185.75M12 20.25c1.472 0 2.882.265 4.185.75M18.75 4.97A48.416 48.416 0 0 0 12 4.5c-2.291 0-4.545.16-6.75.47m13.5 0c1.01.143 2.01.317 3 .52m-3-.52 2.62 10.726c.122.499-.106 1.028-.589 1.202a5.988 5.988 0 0 1-2.031.352 5.988 5.988 0 0 1-2.031-.352c-.483-.174-.711-.703-.59-1.202L18.75 4.971Zm-16.5.52c.99-.203 1.99-.377 3-.52m0 0 2.62 10.726c.122.499-.106 1.028-.589 1.202a5.989 5.989 0 0 1-2.031.352 5.989 5.989 0 0 1-2.031-.352c-.483-.174-.711-.703-.59-1.202L5.25 4.971Z" />
                </svg>
              </div>
              <h3 className="mb-2 text-xl font-semibold">Multi-Currency Support</h3>
              <p className="text-muted-foreground">
                Work with USD, PKR, and more. Automatic currency conversion with real-time rates.
              </p>
            </div>
            
            <div className="glass rounded-lg p-6">
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-secondary/20 text-secondary">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="h-6 w-6">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 8.25h19.5M2.25 9h19.5m-16.5 5.25h6m-6 2.25h3m-3.75 3h15a2.25 2.25 0 0 0 2.25-2.25V6.75A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25v10.5A2.25 2.25 0 0 0 4.5 19.5Z" />
                </svg>
              </div>
              <h3 className="mb-2 text-xl font-semibold">Multi-Bank Management</h3>
              <p className="text-muted-foreground">
                Connect and manage all your bank accounts in one place with detailed transaction tracking.
              </p>
            </div>
            
            <div className="glass rounded-lg p-6">
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-accent/20 text-accent">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="h-6 w-6">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 0 1 3 19.875v-6.75ZM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 0 1-1.125-1.125V8.625ZM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 0 1-1.125-1.125V4.125Z" />
                </svg>
              </div>
              <h3 className="mb-2 text-xl font-semibold">Insightful Reports</h3>
              <p className="text-muted-foreground">
                Visualize your financial data with beautiful charts and comprehensive reports.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="border-t border-border py-16">
        <div className="container flex flex-col items-center text-center">
          <h2 className="mb-4 text-3xl font-bold">Ready to take control of your finances?</h2>
          <p className="mb-8 max-w-[600px] text-muted-foreground">
            Join ZakFinance today and start managing your freelance income like a pro.
          </p>
          <Link to="/signup">
            <Button size="lg">Create Free Account</Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto border-t border-border py-8">
        <div className="container">
          <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
                Z
              </div>
              <span className="font-semibold">ZakFinance</span>
            </div>
            <p className="text-sm text-muted-foreground">
              &copy; {new Date().getFullYear()} ZakFinance. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
