
import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowUpRight, ArrowDownRight, CreditCard, Wallet, DollarSign, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/integrations/supabase/client";
import AddIncomeDialog from "@/components/transactions/AddIncomeDialog";
import AddExpenseDialog from "@/components/transactions/AddExpenseDialog";
import { useNavigate } from "react-router-dom";

interface BankAccount {
  id: string;
  name: string;
  currency: string;
  balance: number;
}

interface Transaction {
  id: string;
  type: 'income' | 'expense';
  original_amount: number;
  original_currency: string;
  description: string;
  transaction_date: string;
  bank_account: {
    name: string;
  };
  category: {
    name: string;
  };
}

const Dashboard = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [accounts, setAccounts] = useState<BankAccount[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [totalBalance, setTotalBalance] = useState({
    balance: 0,
    pkrBalance: 0,
    growth: 0,
    isPositive: true,
  });
  const [recentTransactions, setRecentTransactions] = useState<Transaction[]>([]);
  const [showIncomeDialog, setShowIncomeDialog] = useState(false);
  const [showExpenseDialog, setShowExpenseDialog] = useState(false);
  
  // Map account names to icons and colors
  const accountIconMap: Record<string, { icon: any; color: string }> = {
    'Payoneer': { icon: CreditCard, color: 'primary' },
    'Meezan Bank': { icon: Wallet, color: 'secondary' },
    'JazzCash': { icon: Wallet, color: 'accent' },
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
        
        if (sessionError || !sessionData.session) {
          toast({
            title: "Authentication Error",
            description: "Please sign in to view your dashboard",
          });
          navigate('/signin');
          return;
        }

        // Fetch bank accounts
        const { data: accountsData, error: accountsError } = await supabase
          .from('bank_accounts')
          .select('*')
          .order('created_at');
          
        if (accountsError) {
          console.error('Error fetching accounts:', accountsError);
          toast({
            title: "Failed to load accounts",
            description: accountsError.message,
            variant: "destructive"
          });
          return;
        }

        // Fetch recent transactions
        const { data: transactionsData, error: transactionsError } = await supabase
          .from('transactions')
          .select('*, bank_account:bank_accounts(name), category:categories(name)')
          .order('transaction_date', { ascending: false })
          .limit(5);

        if (transactionsError) {
          console.error('Error fetching transactions:', transactionsError);
        }

        // Calculate total balance
        let totalPkr = 0;
        let exchangeRate = 279.5; // Default exchange rate USD to PKR

        // Get latest USD to PKR exchange rate
        const { data: rateData } = await supabase
          .from('exchange_rates')
          .select('*')
          .eq('from_currency', 'USD')
          .eq('to_currency', 'PKR')
          .order('created_at', { ascending: false })
          .limit(1);

        if (rateData && rateData.length > 0) {
          exchangeRate = rateData[0].rate;
        }

        if (accountsData) {
          accountsData.forEach(account => {
            if (account.currency === 'USD') {
              totalPkr += account.balance * exchangeRate;
            } else {
              totalPkr += account.balance;
            }
          });

          setAccounts(accountsData);
          setTotalBalance({
            balance: totalPkr,
            pkrBalance: totalPkr,
            growth: 7.6, // This would ideally be calculated from historical data
            isPositive: true,
          });
        }

        if (transactionsData) {
          setRecentTransactions(transactionsData);
        }
      } catch (error) {
        console.error('Unexpected error:', error);
        toast({
          title: "An unexpected error occurred",
          description: "Please try again later",
          variant: "destructive"
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, [toast, navigate]);

  const handleRefresh = () => {
    setIsLoading(true);
    // Re-fetch data by triggering the useEffect
    const fetchData = async () => {
      try {
        // Fetch bank accounts
        const { data: accountsData, error: accountsError } = await supabase
          .from('bank_accounts')
          .select('*')
          .order('created_at');
          
        if (accountsError) {
          console.error('Error fetching accounts:', accountsError);
          toast({
            title: "Failed to load accounts",
            description: accountsError.message,
            variant: "destructive"
          });
          return;
        }

        // Fetch recent transactions
        const { data: transactionsData, error: transactionsError } = await supabase
          .from('transactions')
          .select('*, bank_account:bank_accounts(name), category:categories(name)')
          .order('transaction_date', { ascending: false })
          .limit(5);

        if (transactionsError) {
          console.error('Error fetching transactions:', transactionsError);
        }

        // Calculate total balance
        let totalPkr = 0;
        let exchangeRate = 279.5; // Default exchange rate USD to PKR

        // Get latest USD to PKR exchange rate
        const { data: rateData } = await supabase
          .from('exchange_rates')
          .select('*')
          .eq('from_currency', 'USD')
          .eq('to_currency', 'PKR')
          .order('created_at', { ascending: false })
          .limit(1);

        if (rateData && rateData.length > 0) {
          exchangeRate = rateData[0].rate;
        }

        if (accountsData) {
          accountsData.forEach(account => {
            if (account.currency === 'USD') {
              totalPkr += account.balance * exchangeRate;
            } else {
              totalPkr += account.balance;
            }
          });

          setAccounts(accountsData);
          setTotalBalance({
            balance: totalPkr,
            pkrBalance: totalPkr,
            growth: 7.6, // This would ideally be calculated from historical data
            isPositive: true,
          });
        }

        if (transactionsData) {
          setRecentTransactions(transactionsData);
        }
      } catch (error) {
        console.error('Unexpected error:', error);
        toast({
          title: "An unexpected error occurred",
          description: "Please try again later",
          variant: "destructive"
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  };

  if (isLoading) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="h-16 w-16 rounded-full border-4 border-primary border-r-transparent animate-spin" />
          <p className="text-lg text-primary">Loading Dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setShowIncomeDialog(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Add Income
          </Button>
          <Button size="sm" onClick={() => setShowExpenseDialog(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Add Expense
          </Button>
        </div>
      </div>

      {/* Account cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {accounts.map((account) => {
          const accountIcon = accountIconMap[account.name] || { icon: CreditCard, color: 'primary' };
          const Icon = accountIcon.icon;
          const colorClass = `text-${accountIcon.color}`;

          return (
            <Card key={account.id} className="glass overflow-hidden neon-glow">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  {account.name}
                </CardTitle>
                <Icon className={`h-4 w-4 ${colorClass}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {account.currency === "USD" ? "$" : "Rs"}{account.balance.toLocaleString()}
                  <span className="text-xs font-normal text-muted-foreground ml-1">
                    {account.currency}
                  </span>
                </div>
                {account.currency === 'USD' && (
                  <div className="text-sm text-muted-foreground">
                    ≈ Rs{(account.balance * 279.5).toLocaleString()} PKR
                  </div>
                )}
                <div className="mt-2 flex items-center text-sm">
                  <ArrowUpRight className="mr-1 h-4 w-4 text-green-500" />
                  <span className="text-green-500">
                    5.2%
                  </span>
                  <span className="text-muted-foreground ml-1">from last month</span>
                </div>
              </CardContent>
            </Card>
          );
        })}

        <Card className="glass overflow-hidden neon-glow-accent">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Total Balance (PKR)
            </CardTitle>
            <DollarSign className="h-4 w-4 text-accent" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              Rs{totalBalance.pkrBalance.toLocaleString()}
              <span className="text-xs font-normal text-muted-foreground ml-1">
                PKR
              </span>
            </div>
            <div className="mt-2 flex items-center text-sm">
              {totalBalance.isPositive ? (
                <ArrowUpRight className="mr-1 h-4 w-4 text-green-500" />
              ) : (
                <ArrowDownRight className="mr-1 h-4 w-4 text-red-500" />
              )}
              <span className={totalBalance.isPositive ? "text-green-500" : "text-red-500"}>
                {totalBalance.growth}%
              </span>
              <span className="text-muted-foreground ml-1">from last month</span>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="grid gap-4 md:grid-cols-2">
        {/* Chart placeholders */}
        <Card className="glass h-[300px]">
          <CardHeader>
            <CardTitle>Income vs Expenses</CardTitle>
            <CardDescription>Monthly comparison for the last 6 months</CardDescription>
          </CardHeader>
          <CardContent className="flex h-[calc(300px-4rem)] items-center justify-center">
            <p className="text-sm text-muted-foreground">
              Charts will be implemented in the next update
            </p>
          </CardContent>
        </Card>
        
        <Card className="glass h-[300px]">
          <CardHeader>
            <CardTitle>Expense Breakdown</CardTitle>
            <CardDescription>By category</CardDescription>
          </CardHeader>
          <CardContent className="flex h-[calc(300px-4rem)] items-center justify-center">
            <p className="text-sm text-muted-foreground">
              Charts will be implemented in the next update
            </p>
          </CardContent>
        </Card>
      </div>
      
      {/* Recent transactions */}
      <Card className="glass">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Recent Transactions</CardTitle>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={handleRefresh}>
                Refresh
              </Button>
              <Button variant="outline" size="sm" onClick={() => navigate('/transactions')}>
                View All
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {recentTransactions.length > 0 ? (
            <div className="rounded-md border border-border/50">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border/50 bg-muted/50">
                    <th className="px-4 py-2 text-left text-sm font-medium">Type</th>
                    <th className="px-4 py-2 text-left text-sm font-medium">Category</th>
                    <th className="px-4 py-2 text-left text-sm font-medium">Amount</th>
                    <th className="px-4 py-2 text-left text-sm font-medium">Account</th>
                    <th className="px-4 py-2 text-left text-sm font-medium">Date</th>
                    <th className="px-4 py-2 text-left text-sm font-medium">Description</th>
                  </tr>
                </thead>
                <tbody>
                  {recentTransactions.map((transaction) => (
                    <tr key={transaction.id} className="border-b border-border/50 hover:bg-muted/25">
                      <td className="px-4 py-2 text-sm">
                        <span className={`rounded-full px-2 py-1 text-xs font-medium ${
                          transaction.type === 'income' ? 'bg-green-500/20 text-green-500' : 'bg-red-500/20 text-red-500'
                        }`}>
                          {transaction.type.charAt(0).toUpperCase() + transaction.type.slice(1)}
                        </span>
                      </td>
                      <td className="px-4 py-2 text-sm">{transaction.category?.name || 'Uncategorized'}</td>
                      <td className="px-4 py-2 text-sm">
                        <span className={transaction.type === 'income' ? 'text-green-500' : 'text-red-500'}>
                          {transaction.original_currency === 'USD' ? '$' : 'Rs'}{transaction.original_amount.toLocaleString()}
                        </span>
                      </td>
                      <td className="px-4 py-2 text-sm">{transaction.bank_account?.name}</td>
                      <td className="px-4 py-2 text-sm">
                        {new Date(transaction.transaction_date).toLocaleDateString()}
                      </td>
                      <td className="px-4 py-2 text-sm">{transaction.description || '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="rounded-md border border-border/50 px-4 py-8 text-center">
              <p className="text-sm text-muted-foreground">No recent transactions</p>
              <Button 
                variant="link" 
                className="mt-2"
                onClick={() => setShowIncomeDialog(true)}
              >
                Add your first transaction
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Transaction Dialogs */}
      <AddIncomeDialog 
        open={showIncomeDialog} 
        onOpenChange={setShowIncomeDialog}
        onTransactionAdded={handleRefresh}
      />
      
      <AddExpenseDialog 
        open={showExpenseDialog} 
        onOpenChange={setShowExpenseDialog}
        onTransactionAdded={handleRefresh}
      />
    </div>
  );
};

export default Dashboard;
