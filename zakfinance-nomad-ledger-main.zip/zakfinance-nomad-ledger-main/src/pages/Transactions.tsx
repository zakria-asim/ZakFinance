
import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import AddIncomeDialog from "@/components/transactions/AddIncomeDialog";
import AddExpenseDialog from "@/components/transactions/AddExpenseDialog";
import TransactionFilters from "@/components/transactions/TransactionFilters";
import { useNavigate } from "react-router-dom";

interface Transaction {
  id: string;
  type: 'income' | 'expense';
  original_amount: number;
  original_currency: string;
  description: string;
  transaction_date: string;
  bank_account: {
    name: string;
  };
  category: {
    name: string;
  };
}

interface FilterState {
  type: string;
  bankAccount: string;
  category: string;
  dateFrom: Date | null;
  dateTo: Date | null;
}

const Transactions = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showIncomeDialog, setShowIncomeDialog] = useState(false);
  const [showExpenseDialog, setShowExpenseDialog] = useState(false);
  const [filters, setFilters] = useState<FilterState>({
    type: "all",
    bankAccount: "all",
    category: "all",
    dateFrom: null,
    dateTo: null,
  });

  const fetchTransactions = async () => {
    try {
      setIsLoading(true);
      
      const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
        
      if (sessionError || !sessionData.session) {
        toast({
          title: "Authentication Error",
          description: "Please sign in to view your transactions",
        });
        navigate('/signin');
        return;
      }

      let query = supabase
        .from('transactions')
        .select('*, bank_account:bank_accounts(name), category:categories(name)')
        .order('transaction_date', { ascending: false });

      // Apply filters
      if (filters.type !== 'all') {
        // Fix: Use type assertion to handle the type properly
        query = query.eq('type', filters.type as 'income' | 'expense');
      }
      
      if (filters.bankAccount !== 'all') {
        query = query.eq('bank_account_id', filters.bankAccount);
      }
      
      if (filters.category !== 'all') {
        query = query.eq('category_id', filters.category);
      }
      
      if (filters.dateFrom) {
        query = query.gte('transaction_date', filters.dateFrom.toISOString().split('T')[0]);
      }
      
      if (filters.dateTo) {
        query = query.lte('transaction_date', filters.dateTo.toISOString().split('T')[0]);
      }

      const { data, error } = await query;

      if (error) {
        throw error;
      }

      setTransactions(data || []);
    } catch (error: any) {
      console.error('Error fetching transactions:', error);
      toast({
        title: "Failed to load transactions",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchTransactions();
  }, [filters]);

  const handleAddTransaction = () => {
    fetchTransactions();
    toast({
      title: "Transaction added",
      description: "Your transaction has been added successfully"
    });
  };

  const handleFilterChange = (newFilters: Partial<FilterState>) => {
    setFilters(prev => ({ ...prev, ...newFilters }));
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Transactions</h1>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setShowIncomeDialog(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Add Income
          </Button>
          <Button size="sm" onClick={() => setShowExpenseDialog(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Add Expense
          </Button>
        </div>
      </div>

      <Card className="glass">
        <CardHeader>
          <CardTitle>All Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          <TransactionFilters onFilterChange={handleFilterChange} />
          
          {isLoading ? (
            <div className="flex h-40 w-full items-center justify-center">
              <div className="h-8 w-8 rounded-full border-2 border-primary border-r-transparent animate-spin" />
            </div>
          ) : transactions.length > 0 ? (
            <div className="rounded-md border border-border/50 mt-4">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border/50 bg-muted/50">
                    <th className="px-4 py-2 text-left text-sm font-medium">Type</th>
                    <th className="px-4 py-2 text-left text-sm font-medium">Category</th>
                    <th className="px-4 py-2 text-left text-sm font-medium">Amount</th>
                    <th className="px-4 py-2 text-left text-sm font-medium">Account</th>
                    <th className="px-4 py-2 text-left text-sm font-medium">Date</th>
                    <th className="px-4 py-2 text-left text-sm font-medium">Description</th>
                  </tr>
                </thead>
                <tbody>
                  {transactions.map((transaction) => (
                    <tr key={transaction.id} className="border-b border-border/50 hover:bg-muted/25">
                      <td className="px-4 py-2 text-sm">
                        <span className={`rounded-full px-2 py-1 text-xs font-medium ${
                          transaction.type === 'income' ? 'bg-green-500/20 text-green-500' : 'bg-red-500/20 text-red-500'
                        }`}>
                          {transaction.type.charAt(0).toUpperCase() + transaction.type.slice(1)}
                        </span>
                      </td>
                      <td className="px-4 py-2 text-sm">{transaction.category?.name || 'Uncategorized'}</td>
                      <td className="px-4 py-2 text-sm">
                        <span className={transaction.type === 'income' ? 'text-green-500' : 'text-red-500'}>
                          {transaction.original_currency === 'USD' ? '$' : 'Rs'}{transaction.original_amount.toLocaleString()}
                        </span>
                      </td>
                      <td className="px-4 py-2 text-sm">{transaction.bank_account?.name}</td>
                      <td className="px-4 py-2 text-sm">
                        {new Date(transaction.transaction_date).toLocaleDateString()}
                      </td>
                      <td className="px-4 py-2 text-sm">{transaction.description || '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center px-4 py-16 text-center">
              <p className="mb-4 text-muted-foreground">
                No transactions found with the applied filters
              </p>
              <Button
                className="text-primary hover:underline"
                variant="link"
                onClick={() => setShowIncomeDialog(true)}
              >
                Add your first transaction
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <AddIncomeDialog 
        open={showIncomeDialog} 
        onOpenChange={setShowIncomeDialog} 
        onTransactionAdded={handleAddTransaction}
      />
      
      <AddExpenseDialog 
        open={showExpenseDialog} 
        onOpenChange={setShowExpenseDialog}
        onTransactionAdded={handleAddTransaction} 
      />
    </div>
  );
};

export default Transactions;
