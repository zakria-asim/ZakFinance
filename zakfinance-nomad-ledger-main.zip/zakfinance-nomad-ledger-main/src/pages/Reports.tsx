
import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/components/ui/use-toast";
import { useNavigate } from "react-router-dom";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell 
} from "recharts";
import { ChartContainer, ChartLegend, ChartLegendContent, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { ChartPie, ChartBar } from "lucide-react";

interface MonthlyData {
  month: string;
  income: number;
  expense: number;
}

interface CategoryData {
  name: string;
  value: number;
  color: string;
}

const chartConfig = {
  income: {
    label: "Income",
    theme: {
      light: "#10b981",
      dark: "#10b981",
    },
  },
  expense: {
    label: "Expense",
    theme: {
      light: "#ef4444",
      dark: "#ef4444",
    },
  },
};

const Reports = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [monthlyData, setMonthlyData] = useState<MonthlyData[]>([]);
  const [categoryData, setCategoryData] = useState<CategoryData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [totalIncome, setTotalIncome] = useState(0);
  const [totalExpenses, setTotalExpenses] = useState(0);
  const [netSavings, setNetSavings] = useState(0);

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D', '#FF6B6B', '#74B9FF', '#55EFC4', '#FAB1A0'];

  useEffect(() => {
    const fetchReportData = async () => {
      try {
        const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
        
        if (sessionError || !sessionData.session) {
          toast({
            title: "Authentication Error",
            description: "Please sign in to view your reports",
            variant: "destructive"
          });
          navigate('/signin');
          return;
        }
        
        // Get last 6 months
        const months = Array.from({ length: 6 }, (_, i) => {
          const date = new Date();
          date.setMonth(date.getMonth() - i);
          return {
            month: date.toLocaleString('default', { month: 'short' }),
            year: date.getFullYear(),
            monthNum: date.getMonth() + 1,
          };
        }).reverse();

        // Monthly Income vs Expense data
        const monthlyResults = await Promise.all(
          months.map(async ({ month, year, monthNum }) => {
            // Get income for this month
            const { data: incomeData, error: incomeError } = await supabase
              .from('transactions')
              .select('original_amount')
              .eq('type', 'income')
              .eq('user_id', sessionData.session.user.id)
              .gte('transaction_date', `${year}-${String(monthNum).padStart(2, '0')}-01`)
              .lt('transaction_date', monthNum === 12 
                ? `${year + 1}-01-01` 
                : `${year}-${String(monthNum + 1).padStart(2, '0')}-01`);

            // Get expenses for this month
            const { data: expenseData, error: expenseError } = await supabase
              .from('transactions')
              .select('original_amount')
              .eq('type', 'expense')
              .eq('user_id', sessionData.session.user.id)
              .gte('transaction_date', `${year}-${String(monthNum).padStart(2, '0')}-01`)
              .lt('transaction_date', monthNum === 12 
                ? `${year + 1}-01-01` 
                : `${year}-${String(monthNum + 1).padStart(2, '0')}-01`);

            if (incomeError || expenseError) {
              console.error('Error fetching monthly data:', incomeError || expenseError);
              return { month, income: 0, expense: 0 };
            }

            const totalIncome = incomeData?.reduce((sum, item) => sum + (parseFloat(item.original_amount.toString()) || 0), 0) || 0;
            const totalExpense = expenseData?.reduce((sum, item) => sum + (parseFloat(item.original_amount.toString()) || 0), 0) || 0;

            return {
              month,
              income: totalIncome,
              expense: totalExpense,
            };
          })
        );

        // Calculate category breakdown data
        const { data: categoryExpenses, error: categoryError } = await supabase
          .from('transactions')
          .select('original_amount, category_id, categories!inner(name)')
          .eq('type', 'expense')
          .eq('user_id', sessionData.session.user.id);

        if (categoryError) {
          console.error('Error fetching category data:', categoryError);
        } else {
          const categoryMap: Record<string, number> = {};
          
          categoryExpenses?.forEach(item => {
            if (!item.categories) return;
            const categoryName = item.categories.name || 'Uncategorized';
            const amount = parseFloat(item.original_amount.toString()) || 0;
            categoryMap[categoryName] = (categoryMap[categoryName] || 0) + amount;
          });
          
          const categoryArray = Object.entries(categoryMap)
            .map(([name, value], index) => ({
              name,
              value,
              color: COLORS[index % COLORS.length]
            }))
            .sort((a, b) => b.value - a.value); // Sort by value in descending order
          
          setCategoryData(categoryArray);
        }
        
        setMonthlyData(monthlyResults);

        // Calculate summary totals
        const currentDate = new Date();
        const startOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).toISOString().split('T')[0];
        const endOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).toISOString().split('T')[0];

        // Get income for this month
        const { data: monthIncome, error: monthIncomeError } = await supabase
          .from('transactions')
          .select('original_amount')
          .eq('type', 'income')
          .eq('user_id', sessionData.session.user.id)
          .gte('transaction_date', startOfMonth)
          .lte('transaction_date', endOfMonth);

        // Get expenses for this month
        const { data: monthExpense, error: monthExpenseError } = await supabase
          .from('transactions')
          .select('original_amount')
          .eq('type', 'expense')
          .eq('user_id', sessionData.session.user.id)
          .gte('transaction_date', startOfMonth)
          .lte('transaction_date', endOfMonth);

        if (!monthIncomeError && !monthExpenseError) {
          const totalMonthlyIncome = monthIncome?.reduce((sum, item) => sum + (parseFloat(item.original_amount.toString()) || 0), 0) || 0;
          const totalMonthlyExpense = monthExpense?.reduce((sum, item) => sum + (parseFloat(item.original_amount.toString()) || 0), 0) || 0;
          
          setTotalIncome(totalMonthlyIncome);
          setTotalExpenses(totalMonthlyExpense);
          setNetSavings(totalMonthlyIncome - totalMonthlyExpense);
        }
      } catch (error) {
        console.error('Unexpected error:', error);
        toast({
          title: "Error",
          description: "Failed to load report data",
          variant: "destructive"
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchReportData();
  }, [toast, navigate]);

  const formatCurrency = (value: number) => {
    return `Rs${value.toLocaleString()}`;
  };

  if (isLoading) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="h-16 w-16 rounded-full border-4 border-primary border-r-transparent animate-spin" />
          <p className="text-lg text-primary">Loading Reports...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Reports</h1>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="h-[350px]">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-base font-normal">Income vs Expenses</CardTitle>
            <ChartBar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent className="h-[calc(350px-4rem)]">
            {monthlyData.length > 0 ? (
              <ChartContainer 
                config={chartConfig} 
                className="h-full w-full"
              >
                <BarChart
                  data={monthlyData}
                  margin={{ top: 10, right: 30, left: 20, bottom: 40 }}
                >
                  <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                  <XAxis 
                    dataKey="month" 
                    tick={{ fontSize: 12 }}
                    axisLine={{ stroke: '#888' }}
                    tickLine={{ stroke: '#888' }}
                  />
                  <YAxis 
                    tick={{ fontSize: 12 }}
                    axisLine={{ stroke: '#888' }}
                    tickLine={{ stroke: '#888' }}
                    tickFormatter={formatCurrency}
                  />
                  <ChartTooltip 
                    content={
                      <ChartTooltipContent 
                        formatter={(value) => formatCurrency(Number(value))}
                      />
                    } 
                  />
                  <Bar 
                    dataKey="income" 
                    name="income" 
                    fill="var(--color-income)"
                    radius={[4, 4, 0, 0]} 
                  />
                  <Bar 
                    dataKey="expense" 
                    name="expense" 
                    fill="var(--color-expense)" 
                    radius={[4, 4, 0, 0]}
                  />
                  <ChartLegend
                    content={<ChartLegendContent />}
                  />
                </BarChart>
              </ChartContainer>
            ) : (
              <div className="flex h-full items-center justify-center">
                <p className="text-sm text-muted-foreground">
                  Not enough data to generate chart
                </p>
              </div>
            )}
          </CardContent>
        </Card>
        
        <Card className="h-[350px]">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-base font-normal">Expense Breakdown</CardTitle>
            <ChartPie className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent className="h-[calc(350px-4rem)]">
            {categoryData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="45%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => 
                      `${name}: ${(percent * 100).toFixed(0)}%`
                    }
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                  <Legend 
                    layout="horizontal"
                    verticalAlign="bottom"
                    align="center"
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex h-full items-center justify-center">
                <p className="text-sm text-muted-foreground">
                  Not enough data to generate chart
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Monthly Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-muted-foreground">Total Income</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-green-500">{formatCurrency(totalIncome)}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-muted-foreground">Total Expenses</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl font-bold text-red-500">{formatCurrency(totalExpenses)}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-muted-foreground">Net Savings</CardTitle>
              </CardHeader>
              <CardContent>
                <p className={`text-2xl font-bold ${netSavings >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                  {formatCurrency(netSavings)}
                </p>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Reports;
